package com.example.hhver03;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.ktx.Firebase;

import java.util.HashMap;
import java.util.Map;

public class telaCadastro extends AppCompatActivity {

    private EditText nomeRegistro;
    private EditText idadeRegistro;
    private RadioGroup radioGroup;
    private EditText generoRegistro;
    private EditText cidadeRegistro;
    private EditText senhaRegistro;
    private EditText emailRegistro;
    private CheckBox checkPaciente;
    private CheckBox checkPsicologo;
    private Button cadastrarRegistro;
    private EditText editTextCPF;
    private EditText editTextCRP;
    private Usuario usuario;
    private FirebaseAuth autenticacao;



    String[] mensagens = {"Preencha todos os campos", "Cadastro realizado com sucesso"};
    String usuarioId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro);
        getSupportActionBar().hide();
        iniciarComponentes();
       // editTextCRP.setEnabled(false);
        //editTextCPF.setEnabled(false);


        cadastrarRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                usuario = new Usuario();
                usuario.setNome(nomeRegistro.getText().toString());
                usuario.setEmail(emailRegistro.getText().toString());
                usuario.setSenha(senhaRegistro.getText().toString());

                String nome = nomeRegistro.getText().toString();
                String email = emailRegistro.getText().toString();
                String senha = senhaRegistro.getText().toString();

                if(nome.isEmpty() || email.isEmpty() || senha.isEmpty()){
                Snackbar snackbar  = Snackbar.make(view,mensagens[0],Snackbar.LENGTH_SHORT);
                snackbar.setBackgroundTint(Color.WHITE);
                snackbar.setTextColor(Color.BLACK);
                snackbar.show();
                }else{
                    System.out.println("O usuario foi cadastrado");
                    cadastrar(view);




                }

            }
        });


    }

    private void cadastrar(View view){
    autenticacao = ConfiguracaoFirebase.getFirebaseAutenticacao();
    autenticacao.createUserWithEmailAndPassword(
            usuario.getEmail(),
            usuario.getSenha()
    ).addOnCompleteListener(
            this,
            new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {

                        Snackbar snackbar = Snackbar.make(view, mensagens[1], Snackbar.LENGTH_SHORT);
                        snackbar.setBackgroundTint(Color.WHITE);
                        snackbar.setTextColor(Color.BLACK);
                        SalvarDadosUsuario();
                        snackbar.show();

                        snackbar.dismiss();
                        Intent intent = new Intent(telaCadastro.this, homePage.class);
                        startActivity(intent);
                        finish();
                    } else {
                        String erro;
                        try {
                            throw task.getException();
                        } catch (FirebaseAuthWeakPasswordException e) {
                            erro = "Digite uma senha com mais de 6 caracteres;";
                        } catch (FirebaseAuthUserCollisionException e) {
                            erro = "Este e-mail já foi utilizado;";

                        } catch (FirebaseAuthInvalidCredentialsException e) {
                            erro = "E-mail inválido;";
                        } catch (Exception e) {
                            erro = "Erro ao cadastrar usuário";
                            e.printStackTrace();
                        }
                    }
                }
            }
    );


    }


    private void SalvarDadosUsuario(){
        String nome = nomeRegistro.getText().toString();
        String idade = idadeRegistro.getText().toString();
        String genero = generoRegistro.getText().toString();
        String cidade = cidadeRegistro.getText().toString();
        String gen = "";
        if (checkPsicologo.isChecked()){
        //editTextCRP.setEnabled(true);
        //editTextCPF.setEnabled(true);
        }else{
          //  editTextCRP.setEnabled(false);
            //editTextCPF.setEnabled(false);
        }



        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Map<String, Object> usuarios = new HashMap<>();

        usuarios.put("nome", nome);
        usuarios.put("idade", idade);
        usuarios.put("genero", genero);
        usuarios.put("cidade", cidade);


        usuarioId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        db.collection("usuarios").add(usuarios);
        System.out.println("O usuario foi cadastrado no BD = " + usuarioId);
        DocumentReference documentReference = db.collection("usuarios").document(usuarioId);
        documentReference.set(usuarios).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Log.d("db", "Sucesso ao salvar os dados");
            }
        })

                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("db_error", "Erro ao salvar os dados" + e.toString());
                    }
                });
    }

    private void cadastroPsicologo(){


    }

    private void iniciarComponentes(){
        cadastrarRegistro = findViewById(R.id.cadastroRegistro);
        emailRegistro = findViewById(R.id.emailRegistro);
        senhaRegistro = findViewById(R.id.senhaRegistro);
        nomeRegistro = findViewById(R.id.nomeRegistro);
        checkPsicologo = findViewById(R.id.checkPsicologo);
       // editTextCPF = findViewById(R.id.editTextCPF);
      //  editTextCRP = findViewById(R.id.editTextCRP);

        nomeRegistro.requestFocus();
    }

}
