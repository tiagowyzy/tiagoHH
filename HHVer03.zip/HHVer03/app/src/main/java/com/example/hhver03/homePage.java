package com.example.hhver03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;

public class homePage extends AppCompatActivity {
    private ImageView irPerfil;
    private ImageView irPesquisa;
    private TextView anotarPensamento;
    private WebView webView;
    String url;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        url = "https://einstein.br/saudemental";


        getSupportActionBar().hide();
        iniciarComponentes();


        webView.loadUrl(url);


        anotarPensamento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(homePage.this, telaEscreverPensamento.class);
                startActivity(intent);
                finish();
            }
        });
        irPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(homePage.this, telaPerfil.class);
                startActivity(intent);
                finish();
            }
        });
        irPesquisa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(homePage.this, telaPesquisa.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void iniciarComponentes() {
        irPerfil=findViewById(R.id.irPerfil);
        irPesquisa=findViewById(R.id.irPesquisa);
        anotarPensamento = findViewById(R.id.anotarPenasmento);
        webView = findViewById(R.id.webview);

    }
}