package com.example.hhver03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class telaEditarPerfil extends AppCompatActivity {
    private TextView textEditNome;
    private TextView textEditSenha;
    private TextView textEditEmail;
    private TextView deslogar;
    private Button buttonConfirmar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_editar_perfil);
        getSupportActionBar().hide();
        iniciarComponentes();


        deslogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(telaEditarPerfil.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });



        buttonConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(telaEditarPerfil.this, telaPerfil.class);
                startActivity(intent);
                finish();
            }
        });

    }

    private void iniciarComponentes() {
        textEditEmail = findViewById(R.id.textEditEmail);
        textEditNome = findViewById(R.id.textEditNome);
        textEditSenha = findViewById(R.id.textEditSenha);
        deslogar = findViewById(R.id.deslogar);


        buttonConfirmar = findViewById(R.id.buttonConfirmar);
    }
}