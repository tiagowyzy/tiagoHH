package com.example.hhver03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class telaEscreverPensamento extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_escrever_pensamento);
    }
}