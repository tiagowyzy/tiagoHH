package com.example.hhver03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

public class telaMensagens extends AppCompatActivity {
    private ImageView irPerfil;
    private ImageView irPesquisa;
    private ImageView irMensagens;
    private ImageView irHomepage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_mensagens);

    iniciarComponentes();
    }

    private void iniciarComponentes() {
        irPerfil = findViewById(R.id.irPerfil);
        irPesquisa = findViewById(R.id.irPesquisa);
        irMensagens = findViewById(R.id.irMensagens);


    }
}