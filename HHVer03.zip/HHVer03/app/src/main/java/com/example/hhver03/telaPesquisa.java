package com.example.hhver03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class telaPesquisa extends AppCompatActivity {
private ImageView backButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_pesquisa);
        getSupportActionBar().hide();
        iniciarComponentes();

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(telaPesquisa.this, homePage.class);
                startActivity(intent);
                finish();
            }
        });
    }


    private void iniciarComponentes() {
   backButton=findViewById(R.id.backButton);
    }
}