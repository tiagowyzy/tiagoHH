package com.example.hhver03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class telaPerfil extends AppCompatActivity {
private Button buttonEditarPerfil;
private ImageView irPesquisa;
private TextView txtNomeUsuario;
private ImageView irMensagens;
private ImageView irHomepage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_perfil);
        getSupportActionBar().hide();
        iniciarComponentes();



        buttonEditarPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(telaPerfil.this, telaEditarPerfil.class);
                startActivity(intent);

            }
        });
        irPesquisa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(telaPerfil.this, telaPesquisa.class);
                startActivity(intent);
                finish();
            }
        });
        irHomepage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(telaPerfil.this, homePage.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void iniciarComponentes() {
    buttonEditarPerfil = findViewById(R.id.buttonEditalPerfil);
    irPesquisa = findViewById(R.id.irPesquisa);
    irMensagens=findViewById(R.id.irMensagens);
    irHomepage=findViewById(R.id.irHomepage);
    txtNomeUsuario = findViewById(R.id.txtNomeUsuario);


    }
}