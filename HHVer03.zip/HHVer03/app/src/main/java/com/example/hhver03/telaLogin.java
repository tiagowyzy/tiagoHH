package com.example.hhver03;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class telaLogin extends AppCompatActivity {
private TextView irCadastro;
private EditText emailLogin, senhaLogin;
private Button fazerLogin;
private Usuario usuario;
private FirebaseAuth autenticacao;
    String[] mensagens = {"Preencha todos os campos"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_login);

        getSupportActionBar().hide();
        iniciarComponentes();
        irCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(telaLogin.this, telaCadastro.class);
                startActivity(intent);

            }
        });
fazerLogin.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        String email = emailLogin.getText().toString();
        String senha = senhaLogin.getText().toString();
        if(email.isEmpty()||senha.isEmpty()) {

            Snackbar snackbar = Snackbar.make(view, mensagens[0], Snackbar.LENGTH_SHORT);
            snackbar.setBackgroundTint(Color.WHITE);
            snackbar.setTextColor(Color.BLACK);
            snackbar.show();
        }
        AutenticarUsuario(usuario);
    }
});
    }

    private void AutenticarUsuario(Usuario usuario){
        String email = emailLogin.getText().toString();
        String senha = senhaLogin.getText().toString();
    autenticacao = ConfiguracaoFirebase.getFirebaseAutenticacao();
    autenticacao.signInWithEmailAndPassword(
            usuario.getEmail(),
            usuario.getSenha()
    ).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
        @Override
        public void onComplete(@NonNull Task<AuthResult> task) {
            if(task.isSuccessful()){
                telaPrincipal();
            }else{
                String erro;
                try{
                    throw task.getException();
                }catch (Exception e){
                    erro = "Erro ao logar usuário";
                }
                View view = null;
                Snackbar snackbar = Snackbar.make(view, erro, Snackbar.LENGTH_SHORT);
                snackbar.setBackgroundTint(Color.WHITE);
                snackbar.setTextColor(Color.BLACK);
                snackbar.show();
            }
        }
    });
    }

    @Override
    protected void onStart() {
        super.onStart();
        autenticacao = ConfiguracaoFirebase.getFirebaseAutenticacao();

        if(autenticacao.getCurrentUser() != null){
            telaPrincipal();
        }
    }
private void telaPrincipal(){
    Intent intent = new Intent(telaLogin.this, homePage.class);
    startActivity(intent);
    finish();
}
    private void iniciarComponentes(){
        irCadastro = findViewById(R.id.irCadastro);
        emailLogin = findViewById(R.id.emailLogin);
        senhaLogin = findViewById(R.id.senhaLogin);
        fazerLogin = findViewById(R.id.fazerLogin);

        emailLogin.requestFocus();
    }
}
